#oaoa
Script Webhook Line Messaging API Use Heroku Or Other

# 「Keyword」
   - Help
   - /jam 
   - /quotes 
   - /say [teks] 
   - /definition [teks] 
   - /coolteks [teks] 
   - /shalat [lokasi] 
   - /qiblat [lokasi] 
   - /film [teks] 
   - /qr [teks] 
   - /neon [teks] 
   - /light [Judul] 
   - /film-syn [Judul] 
   - /zodiak [tanggal lahir] 
   - /instagram [unsername] 
   - /creator
# 「Done~」



# Deploy to:
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

# Source:
Source : https://medantechno.com/read/news/23/tutorial-membuat-bot-messaging-api-line

PHP Unirest Script Included
